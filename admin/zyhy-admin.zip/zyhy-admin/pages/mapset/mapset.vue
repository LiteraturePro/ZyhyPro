<template>
	<view class="page-body">
		<!-- 页面内容开始 -->

		<!-- 表格搜索组件开始 -->
		<vk-data-table-query
			v-model="queryForm1.formData"
			:columns="queryForm1.columns"
			@search="search"
		></vk-data-table-query>
		<!-- 表格搜索组件结束 -->

		<!-- 自定义按钮区域开始 -->
		<view>
			<el-row>
				<el-button type="success" size="small" icon="el-icon-circle-plus-outline" @click="addBtn">添加</el-button>
			</el-row>
		</view>
		<!-- 自定义按钮区域结束 -->

		<!-- 表格组件开始 -->
		<vk-data-table
			ref="table1"
			:action="table1.action"
			:columns="table1.columns"
			:query-form-param="queryForm1"
			:right-btns="['detail_auto','update','delete']"
			:selection="true"
			:row-no="true"
			:pagination="true"
			@update="updateBtn"
			@delete="deleteBtn"
			@current-change="currentChange"
			@selection-change="selectionChange"
		></vk-data-table>
		<!-- 表格组件结束 -->

		<!-- 添加或编辑的弹窗开始 -->
		<vk-data-dialog
			v-model="form1.props.show"
			:title="form1.props.title"
			width="600px"
			mode="form"
			:close-on-click-modal="false"
		>
		<el-alert
		  title="小提示!"
		  type="success"
		  description="目前只支持到省级,后面会支持到市级等小地区!">
		</el-alert>
			<vk-data-form
				v-model="form1.data"
				:rules="form1.props.rules"
				:action="form1.props.action"
				:form-type="form1.props.formType"
				:columns='form1.props.columns'
				label-width="80px"
				@success="form1.props.show = false;refresh();"
			></vk-data-form>
			
		</vk-data-dialog>
		<!-- 添加或编辑的弹窗结束 -->

		<!-- 页面内容结束 -->
	</view>
</template>

<script>
	var that;													// 当前页面对象
	var vk = uni.vk;									// vk实例
	var originalForms = {};						// 表单初始化数据

	export default {
		data() {
			// 页面数据变量
			return {
				// 页面是否请求中或加载中
				loading:false,
				// init请求返回的数据
				data:{

				},
				// 表格相关开始 -----------------------------------------------------------
				table1:{
					// 表格数据请求地址
					action:"admin/mapset/sys/getList",
					// 表格字段显示规则
					columns:[
						{ key:"name", title:"地区", type:"text" },
						{ key:"degree", title:"次数", type:"tag", width:100,
							data: [
								{ value:0, label:"没去过", tagType:"danger" },
								{ value:1, label:"去过一次", tagType:"info" },
								{ value:2, label:"去过几次", tagType:"" },
								{ value:3, label:"经常去", tagType:"success" },
							]
						}
					],
					// 多选框选中的值
					multipleSelection:[],
					// 当前高亮的记录
					selectItem:""
				},
				// 表格相关结束 -----------------------------------------------------------
				// 表单相关开始 -----------------------------------------------------------
				// 查询表单请求数据
				queryForm1:{
					// 查询表单数据源，可在此设置默认值
					formData:{

					},
					// 查询表单的字段规则 fieldName:指定数据库字段名,不填默认等于key
					columns:[
						 { key:"name", title:"地区", type:"text", width:140, mode:"=" },
						 { key:"allow_login_background", hidden:true, mode:"=" },
					]
				},
				form1:{
					// 表单请求数据，此处可以设置默认值
					data: {

					},
					// 表单属性
					props: {
						// 表单请求地址
						action:"",
						// 表单字段显示规则
						columns:[
							{ key: "name", title:"选择地区", type:"select",
								data:[
									{ value: "安徽", label: "安徽" },
									{ value: "澳门", label: "澳门" },
									{ value: "北京", label: "北京" },
									{ value: "重庆", label: "重庆" },
									{ value: "福建", label: "福建" },
									{ value: "甘肃", label: "甘肃" },
									{ value: "广东", label: "广东" },
									{ value: "广西", label: "广西" },
									{ value: "贵州", label: "贵州" },
									{ value: "海南", label: "海南" },
									{ value: "南海诸岛", label: "南海诸岛" },
									{ value: "河北", label: "河北" },
									{ value: "河南", label: "河南" },
									{ value: "黑龙江", label: "黑龙江" },
									{ value: "湖北", label: "湖北" },
									{ value: "湖南", label: "湖南" },
									{ value: "吉林", label: "吉林" },
									{ value: "江苏", label: "江苏" },
									{ value: "江西", label: "江西" },
									{ value: "辽宁", label: "辽宁" },
									{ value: "内蒙古", label: "内蒙古" },
									{ value: "宁夏", label: "宁夏" },
									{ value: "青海", label: "青海" },
									{ value: "山东", label: "山东" },
									{ value: "山西", label: "山西" },
									{ value: "陕西", label: "陕西" },
									{ value: "上海", label: "上海" },
									{ value: "四川", label: "四川" },
									{ value: "台湾", label: "台湾" },
									{ value: "天津", label: "天津" },
									{ value: "西藏", label: "西藏" },
									{ value: "香港", label: "香港" },
									{ value: "新疆", label: "新疆" },
									{ value: "云南", label: "云南" },
									{ value: "浙江", label: "浙江" },
								]
							},
							{ key: "degree", title:"选择频次", type:"radio" ,
								data:[
									{ value: 0, label: "没去过" },
									{ value: 1, label: "去过一次" },
									{ value: 2, label: "去过几次" },
									{ value: 3, label: "经常去" },
								]
							},
						],
						// 表单对应的验证规则
						rules:{
						  name:[
						      {
						        required: true,
						        validator:vk.pubfn.validator("text"),
						        trigger: 'blur'
						     },
							],
						},
						// add 代表添加 update 代表修改
						formType:"",
						// 是否显示表单的弹窗
						show:false
					}
				},
				// 其他弹窗表单
				formDatas:{},
				// 表单相关结束 -----------------------------------------------------------
			};
		},
		// 监听 - 页面每次【加载时】执行(如：前进)
		onLoad(options = {}) {
			that = this;
			vk = that.vk;
			that.options = options;
			that.init(options);
		},
		// 监听 - 页面【首次渲染完成时】执行。注意如果渲染速度快，会在页面进入动画完成前触发
		onReady() {},
		// 监听 - 页面每次【显示时】执行(如：前进和返回) (页面每次出现在屏幕上都触发，包括从下级页面点返回露出当前页面)
		onShow() {},
		// 监听 - 页面每次【隐藏时】执行(如：返回)
		onHide() {},
		// 函数
		methods: {
			// 页面数据初始化函数
			init(options) {
				originalForms["form1"] = vk.pubfn.copyObject(that.form1);
			},
			// 页面跳转
			pageTo(path) {
				vk.navigateTo(path);
			},
			// 表单重置
			resetForm(){
				vk.pubfn.resetForm(originalForms, that);
			},
			// 搜索
			search(){
				that.$refs.table1.search();
			},
			// 刷新
			refresh(){
				that.$refs.table1.refresh();
			},
			// 获取当前选中的行的数据
			getCurrentRow(){
				return that.$refs.table1.getCurrentRow();
			},
			// 监听 - 行的选中高亮事件
			currentChange(val){
				that.table1.selectItem = val;
			},
			// 当选择项发生变化时会触发该事件
			selectionChange(list) {
				that.table1.multipleSelection = list;
			},
			// 显示添加页面
			addBtn(){
				that.resetForm();
				that.form1.props.action = 'admin/mapset/sys/add';
				that.form1.props.formType = 'add';
				that.form1.props.title = '添加';
				that.form1.props.show = true;
			},
			// 显示修改页面
			updateBtn({ item }){
				that.form1.props.action = 'admin/mapset/sys/update';
				that.form1.props.formType = 'update';
				that.form1.props.title = '编辑';
				that.form1.props.show = true;
				that.form1.data = item;
			},
			// 删除按钮
			deleteBtn({ item, deleteFn }){
				deleteFn({
					action:"admin/mapset/sys/delete",
					data:{
						_id: item._id
					},
				});
			},
			// 监听 - 批量操作的按钮点击事件
			batchBtn(index){
				switch(index){
					case 1: vk.toast("批量操作按钮1"); break;
					case 2: vk.toast("批量操作按钮2"); break;
					default : break;
				}
			}
		},
		// 监听属性
		watch: {

		},
		// 过滤器
		filters: {

		},
		// 计算属性
		computed: {

		}
	};
</script>
<style lang="scss" scoped>
	.page-body {

	}
</style>
