/**
 * vk-unicloud框架客户端(前端)
 * author	VK
 */
import vk from './vk_modules/vk-unicloud-page'

module.exports = vk;