'use strict';
exports.main = async (event, context) => {
	
	/*
	1、参观预约信息
	db: uni-data-order
	field:
		"diagTime": {
		  "bsonType": "string",
		  "description": "日期"
		 },
		"classs": {
		  "bsonType": "string",
		  "description": "身份类型"
		 },
		"idcard": {
		  "bsonType": "string",
		  "description": "身份证号",
		  "format": "idcard"
		},
		"name": {
		  "bsonType": "string",
		  "description": "姓名"
		},
		"time_interval": {
		  "bsonType": "int",
		  "description": "时段"
		},
		"been_to": {
		  "bsonType": "boolean",
		  "description": "过期"
		}
	
	2、意见反馈信息
	db: uni-data-feedback
	field:
	    "user_id": {
	      "bsonType": "string",
	      "title": "用户ID",
	      "description": "用户ID",
	      "trim": "both"
	    },
	    "message": {
	      "bsonType": "string",
	      "title": "反馈信息",
	      "description": "反馈信息",
	      "trim": "both"
	    },
	    "adopt": {
	      "bsonType": "boolean",
	      "title": "是否采纳",
	      "description": "是否采纳",
	      "trim": "both"
	    }
	3、用户评论信息
	db: uni-data-comment
	field:
	
	4、失物招领信息
	db: uni-data-lost
	field:
	    "title": {
	      "bsonType": "string",
	      "title": "物品名称",
	      "description": "物品名称",
	      "trim": "both"
	    },
	    "image": {
	      "bsonType": "array",
	      "title": "图片BIT",
	      "description": "图片BIT",
	      "trim": "right"
	    },
	    "address": {
	      "bsonType": "radio",
	      "title": "领取地址",
	      "description": "领取地址",
	      "trim": "both"
	    },
	    "get_address": {
	      "bsonType": "string",
	      "title": "拾到地址",
	      "description": "拾到地址",
	      "trim": "both"
	    },
	    "get": {
	      "bsonType": "boolean",
	      "title": "是否领取",
	      "description": "是否领取",
	      "trim": "both"
	    }
	5、行程信息
	db: uni-data-trip
	field:
	
	6、收藏信息
	db: uni-data-usercollection
	field:
	
	7、文物登记信息
	db: uni-data-collect
	field:
	    "name": {
	      "bsonType": "string",
	      "title": "文物名称",
	      "description": "文物名称",
	      "trim": "both"
	    },
	    "image": {
	      "bsonType": "array",
	      "title": "文物图片",
	      "description": "文物图片",
	      "trim": "right"
	    },
	    "describe": {
	      "bsonType": "string",
	      "title": "文物描述",
	      "description": "文物描述",
	      "trim": "right"
	    },
	    "user": {
	      "bsonType": "string",
	      "title": "联系人",
	      "description": "联系人",
	      "trim": "right"
	    },
	    "mobile": {
	      "bsonType": "string",
	      "title": "手机号码",
	      "description": "手机号码",
	      "pattern": "^\\+?[0-9-]{3,20}$",
	      "trim": "both"
	    },
	    "address": {
	      "bsonType": "string",
	      "title": "联系地址",
	      "description": "联系地址",
	      "trim": "both"
	    },
	    "read": {
	      "bsonType": "boolean",
	      "title": "是否入库",
	      "description": "是否入库",
	      "trim": "both"
	    }
	8、用户日志信息
	db: uni-data-log
	field:
	    "user_id": {
	      "bsonType": "string",
	      "description": "用户id，参考uni-id-users表"
	    },
	    "ua": {
	      "bsonType": "string",
	      "description": "userAgent"
	    },
	    "device_uuid": {
	      "bsonType": "string",
	      "description": "设备唯一标识"
	    },
	    "type": {
	      "bsonType": "string",
	      "enum": [
	        "login",
	        "logout"
	      ],
	      "description": "登录类型"
	    },
	    "state": {
	      "bsonType": "int",
	      "description": "结果：0 失败、1 成功"
	    },
	    "ip": {
	      "bsonType": "string",
	      "description": "ip地址"
	    },
	    "create_date": {
	      "bsonType": "timestamp",
	      "description": "创建时间",
	      "forceDefaultValue": {
	        "$env": "now"
	      }
	    }
	
	*/
	const db = uniCloud.database();
	let data = []
	let tag = event.queryStringParameters["tag"]
	let res = await db.collection('uni-id-users').where({
	  token: event.queryStringParameters["token"]
	}).get()
	
	if( res.data.length == 0){
		return {
			"code":500,
			"msg":"token验证失败"
		}
	}else{
		if (tag == "uni-data-order"){
			data = {
			  id: event.queryStringParameters["id"],
			  diagTime: event.queryStringParameters["diagTime"],
			  classs: event.queryStringParameters["classs"],
			  idcard: event.queryStringParameters["idcard"],
			  name: event.queryStringParameters["name"],
			  time_interval: event.queryStringParameters["time_interval"],
			  been_to: event.queryStringParameters["been_to"]
			}
		}
		else if (tag == "uni-data-feedback"){
			const collection = db.collection(dbname);
			data = {
			  user_id: event.queryStringParameters["user_id"],
			  message: event.queryStringParameters["message"],
			  adopt: event.queryStringParameters["adopt"]
			}
		}
		else if (tag == "uni-data-lost"){
			data = {
			  title: event.queryStringParameters["title"],
			  image: event.queryStringParameters["image"],
			  address: event.queryStringParameters["address"],
			  get_address: event.queryStringParameters["get_address"],
			  get: event.queryStringParameters["get"]
			}
		}
		else if (tag == "uni-data-collect"){
			data = {
			  name: event.queryStringParameters["name"],
			  image: event.queryStringParameters["image"],
			  describe: event.queryStringParameters["describe"],
			  user: event.queryStringParameters["user"],
			  mobile: event.queryStringParameters["mobile"],
			  address: event.queryStringParameters["address"],
			  read:event.queryStringParameters["read"]
			}
		}
		else if (tag == "uni-id-log"){
			data = {
			  user_id: event.queryStringParameters["user_id"],
			  ua: event.queryStringParameters["ua"],
			  device_uuid: event.queryStringParameters["device_uuid"],
			  type: event.queryStringParameters["type"],
			  state: event.queryStringParameters["state"],
			  ip: event.queryStringParameters["ip"],
			  create_date: event.queryStringParameters["create_date"]
			}
		}
		else{
			data = {
				name: event.queryStringParameters["name"],
				age: event.queryStringParameters["age"]
			}
		}
		// 批量插入数据
		let res = await collection.doc(event.queryStringParameters["_id"]).update(data);

		//返回数据给客户端
		return res;
	}
};
