'use strict';
exports.main = async (event, context) => {
	const db = uniCloud.database();
	const collection = db.collection('uni-id-users');
	let res = await collection.doc(event.queryStringParameters["uid"]).update({
	  avatar: event.queryStringParameters["imagesrc"]
	});
	//返回数据给客户端
	return res;
};
