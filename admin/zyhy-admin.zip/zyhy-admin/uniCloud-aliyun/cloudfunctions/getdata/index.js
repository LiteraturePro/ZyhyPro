'use strict';
exports.main = async (event, context) => {
	
	const db = uniCloud.database();
	let res = await db.collection('uni-id-users').where({
	  token: event.queryStringParameters["token"]
	}).get()
	if( res.data.length == 0){
		return {
			"code":500,
			"msg":"token验证失败"
		}
	}else{
		const collection = db.collection(event.queryStringParameters["DbName"]);
		//返回数据给客户端
		let res = collection.get();
		return res
	}
};
