'use strict';
const uniID = require('uni-id')
exports.main = async (event, context) => {
	const res = await uniID.login({
	    username: event.queryStringParameters["username"],
	    password: event.queryStringParameters["password"],
	    queryField: ['username']
	})
	return res
};
