'use strict';
exports.main = async (event, context) => {
	event为客户端上传的参数
	console.log('event : ', event)
	//event为客户端上传的参数
	const apiUrl = "https://4a2224fd-4003-4b8c-b165-abef8c34b228.bspapp.com/http/router";
	const res = await uniCloud.httpclient.request(apiUrl, {
	    method: 'PUT',
	    data: {
			DbName: 'uni-data-lost'
		},
	    contentType: 'json', // 指定以application/json发送data内的数据
	    dataType: 'json' // 指定返回值为json格式，自动进行parse
	  })
	console.log(res);
	
	
	
	
	// let dbname = 'uni-data-party';
	// let callFunctionResult = await uniCloud.callFunction({
	//     name: "getObject",
	//     data: { "DbName": dbname }
	// })
	// console.log(callFunctionResult["result"]["data"]);
	// //返回数据给客户端
	// return callFunctionResult["result"]["data"]
};
