'use strict';
var moment = require('moment');
exports.main = async (event, context) => {
	
	/*
	1、参观预约信息
	db: uni-data-order
	field:
		"diagTime": {
		  "bsonType": "string",
		  "description": "日期"
		 },
		"classs": {
		  "bsonType": "string",
		  "description": "身份类型"
		 },
		"idcard": {
		  "bsonType": "string",
		  "description": "身份证号",
		  "format": "idcard"
		},
		"name": {
		  "bsonType": "string",
		  "description": "姓名"
		},
		"time_interval": {
		  "bsonType": "int",
		  "description": "时段"
		},
		"been_to": {
		  "bsonType": "boolean",
		  "description": "过期"
		}
	
	2、意见反馈信息
	db: uni-data-feedback
	field:
	    "user_id": {
	      "bsonType": "string",
	      "title": "用户ID",
	      "description": "用户ID",
	      "trim": "both"
	    },
	    "message": {
	      "bsonType": "string",
	      "title": "反馈信息",
	      "description": "反馈信息",
	      "trim": "both"
	    },
	    "adopt": {
	      "bsonType": "boolean",
	      "title": "是否采纳",
	      "description": "是否采纳",
	      "trim": "both"
	    }
	3、用户评论信息
	db: uni-data-comment
	field:
	
	4、失物招领信息
	db: uni-data-lost
	field:
	    "title": {
	      "bsonType": "string",
	      "title": "物品名称",
	      "description": "物品名称",
	      "trim": "both"
	    },
	    "image": {
	      "bsonType": "array",
	      "title": "图片BIT",
	      "description": "图片BIT",
	      "trim": "right"
	    },
	    "address": {
	      "bsonType": "radio",
	      "title": "领取地址",
	      "description": "领取地址",
	      "trim": "both"
	    },
	    "get_address": {
	      "bsonType": "string",
	      "title": "拾到地址",
	      "description": "拾到地址",
	      "trim": "both"
	    },
	    "get": {
	      "bsonType": "boolean",
	      "title": "是否领取",
	      "description": "是否领取",
	      "trim": "both"
	    }
	5、行程信息
	db: uni-data-trip
	field:
	
	6、收藏信息
	db: uni-data-usercollection
	field:
	
	7、文物登记信息
	db: uni-data-collect
	field:
	    "name": {
	      "bsonType": "string",
	      "title": "文物名称",
	      "description": "文物名称",
	      "trim": "both"
	    },
	    "image": {
	      "bsonType": "array",
	      "title": "文物图片",
	      "description": "文物图片",
	      "trim": "right"
	    },
	    "describe": {
	      "bsonType": "string",
	      "title": "文物描述",
	      "description": "文物描述",
	      "trim": "right"
	    },
	    "user": {
	      "bsonType": "string",
	      "title": "联系人",
	      "description": "联系人",
	      "trim": "right"
	    },
	    "mobile": {
	      "bsonType": "string",
	      "title": "手机号码",
	      "description": "手机号码",
	      "pattern": "^\\+?[0-9-]{3,20}$",
	      "trim": "both"
	    },
	    "address": {
	      "bsonType": "string",
	      "title": "联系地址",
	      "description": "联系地址",
	      "trim": "both"
	    },
	    "read": {
	      "bsonType": "boolean",
	      "title": "是否入库",
	      "description": "是否入库",
	      "trim": "both"
	    }
	8、用户日志信息
	db: uni-data-log
	field:
	    "user_id": {
	      "bsonType": "string",
	      "description": "用户id，参考uni-id-users表"
	    },
	    "ua": {
	      "bsonType": "string",
	      "description": "userAgent"
	    },
	    "device_uuid": {
	      "bsonType": "string",
	      "description": "设备唯一标识"
	    },
	    "type": {
	      "bsonType": "string",
	      "enum": [
	        "login",
	        "logout"
	      ],
	      "description": "登录类型"
	    },
	    "state": {
	      "bsonType": "int",
	      "description": "结果：0 失败、1 成功"
	    },
	    "ip": {
	      "bsonType": "string",
	      "description": "ip地址"
	    },
	    "create_date": {
	      "bsonType": "timestamp",
	      "description": "创建时间",
	      "forceDefaultValue": {
	        "$env": "now"
	      }
	    }
	9、添加用户信息
	db: uni-id-users
	field:
		"username": {
	      "bsonType": "string",
	      "title": "用户名",
	      "description": "用户名，不允许重复",
	      "trim": "both"
	    },
	    "password": {
	      "bsonType": "password",
	      "title": "密码",
	      "description": "密码，加密存储",
	      "trim": "both"
	    },
	    "password_secret_version": {
	      "bsonType": "int",
	      "title": "passwordSecret",
	      "description": "密码使用的passwordSecret版本"
	    },
	    "nickname": {
	      "bsonType": "string",
	      "title": "昵称",
	      "description": "用户昵称",
	      "trim": "both"
	    },
	    "gender": {
	      "bsonType": "int",
	      "title": "性别",
	      "description": "用户性别：0 未知 1 男性 2 女性",
	      "defaultValue": 0,
	      "enum": [
	        {
	          "text": "未知",
	          "value": 0
	        },
	        {
	          "text": "男",
	          "value": 1
	        },
	        {
	          "text": "女",
	          "value": 2
	        }
	      ]
	    },
	    "status": {
	      "bsonType": "int",
	      "description": "用户状态：0 正常 1 禁用 2 审核中 3 审核拒绝",
	      "title": "用户状态",
	      "defaultValue": 0,
	      "enum": [
	        {
	          "text": "正常",
	          "value": 0
	        },
	        {
	          "text": "禁用",
	          "value": 1
	        },
	        {
	          "text": "审核中",
	          "value": 2
	        },
	        {
	          "text": "审核拒绝",
	          "value": 3
	        }
	      ]
	    },
	    "mobile": {
	      "bsonType": "string",
	      "title": "手机号码",
	      "description": "手机号码",
	      "pattern": "^\\+?[0-9-]{3,20}$",
	      "trim": "both"
	    },
	    "mobile_confirmed": {
	      "bsonType": "int",
	      "description": "手机号验证状态：0 未验证 1 已验证",
	      "title": "手机号验证状态",
	      "defaultValue": 0,
	      "enum": [
	        {
	          "text": "未验证",
	          "value": 0
	        },
	        {
	          "text": "已验证",
	          "value": 1
	        }
	      ]
	    },
	    "email": {
	      "bsonType": "string",
	      "format": "email",
	      "title": "邮箱",
	      "description": "邮箱地址",
	      "trim": "both"
	    },
	    "email_confirmed": {
	      "bsonType": "int",
	      "description": "邮箱验证状态：0 未验证 1 已验证",
	      "title": "邮箱验证状态",
	      "defaultValue": 0,
	      "enum": [
	        {
	          "text": "未验证",
	          "value": 0
	        },
	        {
	          "text": "已验证",
	          "value": 1
	        }
	      ]
	    },
	    "avatar": {
	      "bsonType": "string",
	      "title": "头像地址",
	      "description": "头像地址",
	      "trim": "both"
	    },
	    "avatar_file": {
	      "bsonType": "file",
	      "title": "头像文件",
	      "description": "用file类型方便使用uni-file-picker组件"
	    },
	    "department_id": {
	      "bsonType": "array",
	      "description": "部门ID",
	      "title": "部门",
	      "enumType": "tree",
	      "enum": {
	        "collection": "opendb-department",
	        "orderby": "name asc",
	        "field": "_id as value, name as text"
	      }
	    },
	    "role": {
	      "bsonType": "array",
	      "title": "角色",
	      "description": "用户角色",
	      "enum": {
	        "collection": "uni-id-roles",
	        "field": "role_id as value, role_name as text"
	      },
	      "foreignKey": "uni-id-roles.role_id",
	      "permission": {
	        "write": false
	      }
	    },
	    "wx_unionid": {
	      "bsonType": "string",
	      "description": "微信unionid"
	    },
	    "wx_openid": {
	      "bsonType": "object",
	      "description": "微信各个平台openid",
	      "properties": {
	        "app-plus": {
	          "bsonType": "string",
	          "description": "app平台微信openid"
	        },
	        "mp-weixin": {
	          "bsonType": "string",
	          "description": "微信小程序平台openid"
	        }
	      }
	    },
	    "ali_openid": {
	      "bsonType": "string",
	      "description": "支付宝平台openid"
	    },
	    "apple_openid": {
	      "bsonType": "string",
	      "description": "苹果登录openid"
	    },
	    "comment": {
	      "bsonType": "string",
	      "title": "备注",
	      "description": "备注",
	      "trim": "both"
	    },
	    "realname_auth": {
	      "bsonType": "object",
	      "description": "实名认证信息",
	      "required": [
	        "type",
	        "auth_status"
	      ],
	      "properties": {
	        "type": {
	          "bsonType": "int",
	          "minimum": 0,
	          "maximum": 1,
	          "description": "用户类型：0 个人用户 1 企业用户"
	        },
	        "auth_status": {
	          "bsonType": "int",
	          "minimum": 0,
	          "maximum": 3,
	          "description": "认证状态：0 未认证 1 等待认证 2 认证通过 3 认证失败"
	        },
	        "auth_date": {
	          "bsonType": "timestamp",
	          "description": "认证通过时间"
	        },
	        "real_name": {
	          "bsonType": "string",
	          "description": "真实姓名/企业名称"
	        },
	        "identity": {
	          "bsonType": "string",
	          "description": "身份证号码/营业执照号码"
	        },
	        "id_card_front": {
	          "bsonType": "string",
	          "description": "身份证正面照 URL"
	        },
	        "id_card_back": {
	          "bsonType": "string",
	          "description": "身份证反面照 URL"
	        },
	        "in_hand": {
	          "bsonType": "string",
	          "description": "手持身份证照片 URL"
	        },
	        "license": {
	          "bsonType": "string",
	          "description": "营业执照 URL"
	        },
	        "contact_person": {
	          "bsonType": "string",
	          "description": "联系人姓名"
	        },
	        "contact_mobile": {
	          "bsonType": "string",
	          "description": "联系人手机号码"
	        },
	        "contact_email": {
	          "bsonType": "string",
	          "description": "联系人邮箱"
	        }
	      }
	    },
	    "score": {
	      "bsonType": "int",
	      "description": "用户积分，积分变更记录可参考：uni-id-scores表定义"
	    },
	    "register_date": {
	      "bsonType": "timestamp",
	      "description": "注册时间",
	      "forceDefaultValue": {
	        "$env": "now"
	      }
	    },
	    "register_ip": {
	      "bsonType": "string",
	      "description": "注册时 IP 地址",
	      "forceDefaultValue": {
	        "$env": "clientIP"
	      }
	    },
	    "last_login_date": {
	      "bsonType": "timestamp",
	      "description": "最后登录时间"
	    },
	    "last_login_ip": {
	      "bsonType": "string",
	      "description": "最后登录时 IP 地址"
	    },
	    "token": {
	      "bsonType": "array",
	      "description": "用户token"
	    },
	    "inviter_uid": {
	      "bsonType": "array",
	      "description": "用户全部上级邀请者",
	      "trim": "both"
	    },
	    "invite_time": {
	      "bsonType": "timestamp",
	      "description": "受邀时间"
	    },
	    "my_invite_code": {
	      "bsonType": "string",
	      "description": "用户自身邀请码"
	    }
	*/
   let tag = event.queryStringParameters["tag"];
   const db = uniCloud.database();
   let data = []
   
   let res = await db.collection('uni-id-users').where({
     token: event.queryStringParameters["token"]
   }).get()
   
   if( res.data.length == 0){
   	return {
   		"code":500,
   		"msg":"token验证失败"
   	}
   }else{
		if (tag == "uni-data-order"){
			data = [{
			  id: event.queryStringParameters["id"],
			  diagTime: event.queryStringParameters["diagTime"],
			  classs: event.queryStringParameters["classs"],
			  idcard: event.queryStringParameters["idcard"],
			  name: event.queryStringParameters["name"],
			  time_interval: event.queryStringParameters["time_interval"],
			  been_to: false
			}]
		}
		else if (tag == "uni-data-feedback"){
			data = [{
			  user_id: event.queryStringParameters["user_id"],
			  message: event.queryStringParameters["message"],
			  adopt: 2,
			  time: moment(Date.now()).utc().zone(-8).format('YYYY-MM-DD HH:mm:ss')
			}]
		}
		else if (tag == "uni-data-lost"){
			data = [{
			  title: event.queryStringParameters["title"],
			  image: event.queryStringParameters["image"],
			  address: event.queryStringParameters["address"],
			  user_id: event.queryStringParameters["user_id"],
			  get: false,
			  add_time: moment(Date.now()).utc().zone(-8).format('YYYY-MM-DD HH:mm:ss')
			}]
		}
		else if (tag == "uni-data-collect"){
			data = [{
			  image: event.queryStringParameters["image"],
			  describe: event.queryStringParameters["describe"],
			  user: event.queryStringParameters["user"],
			  mobile: event.queryStringParameters["mobile"],
			  address: event.queryStringParameters["address"],
			  read:false
			}]
		}
		else if (tag == "uni-id-log"){
			data = [{
			  user_id: event.queryStringParameters["user_id"],
			  ua: event.queryStringParameters["ua"],
			  device_uuid: event.queryStringParameters["device_uuid"],
			  type: event.queryStringParameters["type"],
			  state: event.queryStringParameters["state"],
			  ip: event.queryStringParameters["ip"],
			  create_date: event.queryStringParameters["create_date"]
			}]
		}
		else{
			data = [{
				name: event.queryStringParameters["name"],
				age: event.queryStringParameters["age"]
			}]
		}
		// 批量插入数据
		const collection = db.collection(tag);
		let ress = await collection.add(data);

		//返回数据给客户端
		return ress;
	}
};
