'use strict';
const uniID = require('uni-id')
exports.main = async (event, context) => {
	let token = event.queryStringParameters["token"];
	const encResult = await uniID.logout(token);
	return encResult;
};
