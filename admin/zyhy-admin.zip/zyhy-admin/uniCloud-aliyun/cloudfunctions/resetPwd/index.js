'use strict';
const uniID = require('uni-id')
exports.main = async (event, context) => {
	const db = uniCloud.database();
	if (event.queryStringParameters["tag"] == "0"){
		let res = await db.collection('uni-id-users').where({
			username: event.queryStringParameters["username"]
		}).get()
		
		if( res.data.length == 0){
			return {
				"code":501,
				"msg":"更新失败"
			}
		}else{
			const ress = await uniID.resetPwd({
			    uid: res["data"][0]["_id"],
			    password: event.queryStringParameters["password"]
			})
			return ress
		}
	}else{
		const res = await uniID.resetPwd({
		    uid: event.queryStringParameters["uid"],
		    password: event.queryStringParameters["password"]
		})
		return res
	}
	
};
