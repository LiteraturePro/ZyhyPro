'use strict';
const uniID = require('uni-id')
const vk = require('vk-unicloud')
exports.main = async (event, context) => {
	const Password = event.queryStringParameters["password"];
	const Username = event.queryStringParameters["username"];
	const Mobile = event.queryStringParameters["mobile"];
	
	let Mobile_confirmed = 0;
	  //自己额外增加的校验密码规范的逻辑（可选）
	  //强弱密码校验,密码至少包含大写字母，小写字母，数字，且不少于6位
	  if(!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[^]{6,16}$/.test(Password)){
	    return {
	      code: 401,
	      msg: '密码至少包含大写字母，小写字母，数字，且不少于6位'
	    }
	  }
	  let dbName = "uni-id-users";
	  // 检测username
	  let num = await vk.baseDao.count({
	  	dbName: dbName,
	  	whereJson: {
	  		username: Username
	  	}
	  });
	  if (num > 0) {
	  	return { code: -1, msg: `用户名【${Username}】已注册!` };
	  }
	  // 检测mobile
	  if (Mobile) {
	  	let num = await vk.baseDao.count({
	  		dbName: dbName,
	  		whereJson: {
	  			mobile: Mobile
	  		}
	  	});
	  	if (num > 0) {
	  		return { code: -1, msg: `手机号【${Mobile}】已注册!` };
	  	}
	  	Mobile_confirmed = 1; // 设置该手机号为已验证(否则无法通过手机号进行登录)
	  }
	    // 自动验证用户名是否与已经注册的用户名重复，如果重复会直接返回错误。否则会自动生成token并加密password存储username、password、token到数据表uni-id-users，并返回如上响应参数
		const data = {
		  username: Username,
		  password: Password,
		  mobile: Mobile,
		  mobile_confirmed: Mobile_confirmed,
		  allow_login_background: false,
		  nickname: event.queryStringParameters["username"],
		  //gender: event.queryStringParameters["gender"],
		  gender: 1,
		  role: [
			  "custom-role-1"
			  ],
		  avatar:"https://vkceyugu.cdn.bspapp.com/VKCEYUGU-4a2224fd-4003-4b8c-b165-abef8c34b228/e5c3a815-9c10-4958-88d4-667efba5c7bd.png",
		  comment: null
		}
		const res = await uniID.register(data)
	    return res
};
