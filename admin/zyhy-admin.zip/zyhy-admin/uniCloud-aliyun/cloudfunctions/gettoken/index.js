'use strict';
const uniID = require('uni-id')
exports.main = async (event, context) => {
	const db = uniCloud.database();
	const encResult = await uniID.encryptPwd(event.queryStringParameters["password"])
	let res = await db.collection('uni-id-users').where({
		username: event.queryStringParameters["username"],
	    password: encResult["passwordHash"]
	}).get()
	if( res.data.length == 0){
		return {
			"code":404,
			"msg":"获取token失败！",
			"token":null
		}
	}else{
		return {
			"code":200,
			"msg":"获取token成功！",
			"token":res["data"][0]["token"][0]
		}
	}
};
