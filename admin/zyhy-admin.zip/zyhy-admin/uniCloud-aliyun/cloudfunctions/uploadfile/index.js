'use strict';
const fs = require("fs");
exports.main = async (event, context) => {
	const db = uniCloud.database();
	var obj = JSON.parse(event.body);
	let base64 = obj["buffer"];

	var dataBuffer = new Buffer(base64, 'base64'); // 解码图片
	
	let CloudPath = Date.now()+".png"
	let res = await db.collection('uni-id-users').where({
	   token: obj["token"]
	 }).get()
	if( res.data.length == 0){
		return {
			"code":500,
			"msg":"token验证失败"
		}
	}else{
		// return {
		// 	"code":event.queryStringParameters["token"],
		// 	"msg":event.queryStringParameters["uuid"],
		// 	"body":obj["token"]
		// }
		let result = await uniCloud.uploadFile({
			cloudPath: CloudPath,
			fileContent: dataBuffer,
		 });
		return result;
	}
};
