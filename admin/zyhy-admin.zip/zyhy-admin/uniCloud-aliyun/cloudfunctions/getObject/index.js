'use strict';
exports.main = async (event, context) => {
	//event为客户端上传的参数
	const db = uniCloud.database();
	// 获取集合的引用
	const collection = db.collection(event.DbName);
	//返回数据给客户端
	let res = collection.get();
	return res
};
