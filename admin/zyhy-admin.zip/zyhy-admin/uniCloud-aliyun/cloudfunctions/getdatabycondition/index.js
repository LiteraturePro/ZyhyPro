'use strict';
exports.main = async (event, context) => {
	const db = uniCloud.database();
	let res = await db.collection('uni-id-users').where({
	  token: event.queryStringParameters["token"]
	}).get()
	if( res.data.length == 0){
		return {
			"code":500,
			"msg":"token验证失败"
		}
	}else{
		if(event.queryStringParameters["DbName"] == "uni-data-collection"){
			const collection = db.collection(event.queryStringParameters["DbName"]);
			//返回数据给客户端
			let res = collection.where({
			  classs: event.queryStringParameters["condition"]
			}).get();
			return res
		}else{
			const collection = db.collection(event.queryStringParameters["DbName"]);
			//返回数据给客户端
			let res = collection.where({
			  classs: event.queryStringParameters["condition"]
			}).get();
			return res
		}
	}
};
