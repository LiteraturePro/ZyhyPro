## PC后台admin管理端
#### `router/service/admin` 目录为后台管理端逻辑
#### 以下的目录并非强制性，只是建议，便于统一开发规范。

```
.
├── admin──────────────────────# 后台管理端逻辑
│ └── platform──────────────# 总平台端
│ └── agent─────────────────# 代理商端
│ └── system────────────────# 系统
│ ── └── xxxxxxxxxxxxxxx──────# 
│ ── └── xxxxxxxxxxxxxxx──────# 
│ ── └── xxxxxxxxxxxxxxx──────# 
│ ── └── xxxxxxxxxxxxxxx──────# 
└─────────────────────────────────
```
