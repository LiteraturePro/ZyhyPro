'use strict';
const uniID = require('uni-id')
exports.main = async (event, context) => {
	const res = await uniID.getUserInfo({
	    uid: event.queryStringParameters["uid"]
	  })
	return res["userInfo"]
};
