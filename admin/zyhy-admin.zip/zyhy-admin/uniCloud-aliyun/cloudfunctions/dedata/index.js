'use strict';
exports.main = async (event, context) => {
	let dbname = event.queryStringParameters["DbName"];
	const db = uniCloud.database();
	const collection = db.collection(dbname);
	
	let res = await db.collection('uni-id-users').where({
	  token: event.queryStringParameters["token"]
	}).get()
	
	if( res.data.length == 0){
		return {
			"code":500,
			"msg":"token验证失败"
		}
	}else{
		let res = await collection.doc(event.queryStringParameters["_id"]).remove();
		//返回数据给客户端
		return res;
	}
};
