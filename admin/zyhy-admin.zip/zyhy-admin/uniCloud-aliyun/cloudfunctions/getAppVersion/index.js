'use strict';
exports.main = async (event, context) => {
	let callFunctionResult = await uniCloud.callFunction({
		name: "getObject",
		data: { "DbName": "AppVersion"}
	})
	//返回数据给客户端
	return callFunctionResult["result"]["data"][0]
};
