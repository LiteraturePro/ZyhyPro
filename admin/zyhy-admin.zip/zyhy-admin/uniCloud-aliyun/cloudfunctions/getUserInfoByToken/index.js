'use strict';
const uniID = require('uni-id')
exports.main = async (event, context) => {
	const res = await uniID.getUserInfoByToken(event.queryStringParameters["token"]);
	//const res = await uniID.getUserInfoByToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MTE0OGJlODBkMzA2OTAwMDE3OGViZWYiLCJyb2xlIjpbImN1c3RvbS1yb2xlLTEiXSwicGVybWlzc2lvbiI6WyJzeXMtcGVybWlzc2lvbiIsInN5cy1wZXJtaXNzaW9uLWFkZCIsInN5cy1wZXJtaXNzaW9uLWRlbGV0ZSIsInN5cy1wZXJtaXNzaW9uLXVwZGF0ZSIsInN5cy1wZXJtaXNzaW9uLXJlYWQiLCJzeXMtbWFuYWdlIiwic3lzLW1hbmFnZS11c2VyIiwic3lzLW1hbmFnZS1yb2xlIiwic3lzLW1hbmFnZS1wZXJtaXNzaW9uIiwic3lzLW1hbmFnZS1tZW51Il0sImlhdCI6MTYyODczNjQ4OCwiZXhwIjoxNjI5MzQxMjg4fQ.i65wdfkb8GDKqXtYa2D3UrsWagLmt1whgIYRPuAM5Qs");
	return res
};
