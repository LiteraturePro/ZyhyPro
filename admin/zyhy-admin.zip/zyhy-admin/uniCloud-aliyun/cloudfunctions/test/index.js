'use strict';
const uniID = require('uni-id')
exports.main = async (event, context) => {
	let Token = event.queryStringParameters["token"];
	const encResult = await uniID.checkToken({
		token: Token,
		checkTokenOptions: null
	})
	return encResult;
};
