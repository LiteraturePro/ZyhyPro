module.exports = async function (rule, value, data) {
   //event为客户端上传的参数
	const apiUrl = "https://2cff8864-a6ba-4282-bc30-3f0f060d7a34.bspapp.com/http/getplacejson";
	const res = await uniCloud.httpclient.request(apiUrl, {
	    method: 'GET',
	    data: {},
	    contentType: 'json', // 指定以application/json发送data内的数据
	    dataType: 'json' // 指定返回值为json格式，自动进行parse
	  })
	//console.log(res["data"]["data"])
	//返回数据给客户端
	var i = 0;
	var ite = true;
	while (i < res["data"]["data"].length-1)
	{
		if(value == res["data"]["data"][0]["name"].toString())
		{
			ite = false;
			break;
		}
	    i++;
	}
	return ite
  }