## 1.3.3（2021-07-12）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 【修复】已知问题

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.3.2（2021-07-12）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.3.2`
#### 2、【优化】部分输入性组件补全 readonly（只读）属性
#### 3、【修复】连表查询时，因`lastWhereJson`而导致`getCount`错误的问题。

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.3.1（2021-07-12）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.3.2`
#### 2、【优化】部分输入性组件补全 readonly（只读）属性
#### 3、【修复】连表查询时，因`lastWhereJson`而导致`getCount`错误的问题。

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.3.0（2021-07-09）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.3.0`
#### 2、【升级】`element-ui` 包升级至 `2.15.3`(有新增2个组件) [查看elementUI更新日志](https://element.eleme.cn/#/zh-CN/component/changelog)
#### 3、【重要调整】删除了`config`公共模块，升级为`uni-config-center`模式 [点击查看升级教程](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4219337&doc_id=975983)
#### 3、【重要调整】删除了`config`公共模块，升级为`uni-config-center`模式 [点击查看升级教程](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4219337&doc_id=975983)
#### 3、【重要调整】删除了`config`公共模块，升级为`uni-config-center`模式 [点击查看升级教程](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4219337&doc_id=975983)
#### 4、【重要】万能表格搜索组件`vk-data-table-query`文档（支持搜索折叠） [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4214905&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.7（2021-07-07）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.18`
#### 2、【新增】`admin/system/menu/sys/getCascader`（cascader 级联选择组件 远程懒加载方式的云函数示例）[点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050268&doc_id=975983)
#### 3、【新增】`万能表格`新增合计列的属性show-summary、summary-method 、total-option [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003876&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.6（2021-07-05）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.16`
#### 2、【优化】权限管理页面逻辑（部分修改完成后，减少一次数据库查询）
#### 3、【优化】菜单管理页面逻辑（部分修改完成后，减少一次数据库查询）
#### 4、【优化】优化手机H5浏览时的部分样式。

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.5（2021-07-03）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.15`
#### 2、【调整】去除系统内置的`初级管理员`、`中级管理员`、`高级管理员`角色
#### 3、【优化】权限管理页面逻辑

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.4（2021-07-03）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.15`
#### 2、【调整】万能表格 `getCurrentRow()` 方法调整如下
```js
// 获取当前选中行的数据（拷贝一份新的数据），此时若改变item对象内属性的值，不影响表格本行数据。
let item = that.$refs.table1.getCurrentRow();
// 获取当前选中行的数据，此时若改变item对象内属性的值，可以实时更新表格本行数据。
let item = that.$refs.table1.getCurrentRow(true);
```
#### 3、【修复】万能表单 `checkbox` 第二次显示可能会报错的问题。


#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.3（2021-07-02）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.12`
#### 2、【修复】`万能表单`的 `remote-select` 当 showAll:true 时，actionData参数无效的问题。
#### 3、【修复】`万能表单`的 `file-select` 已知bug。


#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.2（2021-07-01）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.9`
#### 2、【修复】`素材管理`优化。需替换目录`/pages_plugs/system_uni/uni-id-files/`
#### 3、【优化】`万能表单`的 `remote-select`、 `radio`、 `checkbox`新增属性 `dataPreprocess`（数据预处理函数）[点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050267&doc_id=975983)
#### 4、【修复】`万能表单`的 `file-select` 已知bug [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4176041&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.1（2021-06-28）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.7`
#### 2、【修复】已知bug

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.2.0（2021-06-28）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.2.6`
#### 2、【修复】`manifest.json`的 H5 配置中运行的基础路径 由 `admin` 改成 `/admin/`（规范）（如果你的前端托管只发布admin，则可以设置为空）
#### 3、【新增】万能表单新增 `file-select` 组件（素材库选择组件），可以直接选择已上传的素材。[点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4176041&doc_id=975983)
#### 4、【重要】新增 `素材管理` 页面，可管理已上传的图片、视频、文件等素材。[点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4176041&doc_id=975983)
![](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-cf0c5e69-620c-4f3c-84ab-f4619262939f/f795789f-a7e7-4117-953f-07fe2a25f300.png)
#### 5、【优化】万能表单`remote-select` 新增属性`actionData` [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050267&doc_id=975983)
#### 6、【优化】万能表单`radio` 新增属性`actionData`   [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050276&doc_id=975983)
#### 7、【优化】万能表单`checkbox` 新增属性`actionData`  [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050277&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。


## 1.1.9（2021-06-23）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.19`
#### 2、【修复】`万能表格` 导出 `Excel` 的一些已知问题。

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。


## 1.1.8（2021-06-22）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.17`
#### 2、【修复】`万能表单` 组件 `table-select` 当设置为单选时 `onChange` 事件 返回参数 `option` 的值改为对象（之前是数组）[点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050276&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论。
## 1.1.7（2021-06-21）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.15`
#### 2、【升级】`element-ui` 包升级至 `2.15.2`
#### 3、【优化】`万能表单` 组件 `remote-select`、`table-select`、`select`、`checkbox`、`radio` 的 `onChange` 事件 新增返回参数 `option` 值为选项的对象值 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050276&doc_id=975983)
```js
{
  key:"user_id", title:"用户选择器", type:"remote-select", placeholder:"请输入用户账号/昵称",
  action:"admin/select/kh/user",
  onChange:function(val, formData, column, index, option){
    // option内的值为与val匹配的选项的数据源完整数据
    console.log(1,val, formData, column, index, option);
  }
}
```

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。
## 1.1.6（2021-06-18）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.13`
#### 2、【修复】`vk.baseDao.add` 因hbx 3.1.18版本导致的本地运行时 `_add_time_str` 错误的问题。
#### 3、【新增】万能表单 `array<object>` 的 `columns` 中每个元素新增 `onChange` 属性 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4109698&doc_id=975983)
#### 4、【新增】万能表单 `table-select` 新增 `valueFields` 属性（用于控制value的值由哪些字段组成） [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050269&doc_id=975983)
```js
// 不设置 `valueFields` 时 表单绑定的值为`字符串数组形式`
["001","002"]
// 设置 `valueFields` 时 表单绑定的值为`对象数组形式`
// 如 `valueFields:["_id","nickname","mobile"]` 表单绑定的值为
[
  {"_id":"001","nickname":"昵称1","mobile":"手机号1"}，
  {"_id":"002","nickname":"昵称2","mobile":"手机号2"}
]
```
#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。


## 1.1.5（2021-06-15）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.11`
#### 2、【新增】`万能表单` 新增组件 `array<object>`(子表单-对象数组)  [点击查看文档](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4109698&doc_id=975983)
#### ![查看示例图](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-cf0c5e69-620c-4f3c-84ab-f4619262939f/67cda695-e3f9-469f-9870-9f248b415400.png)
#### 3、【新增】`万能表单` 新增组件 `array<string>`(字符串数组) 
 ```js
{ key:"array1", title:"数组字符串类型", type:"array<string>" }
```

#### 4、【新增】`万能表单` 新增组件 `array<number>`(数字数组)  
```js
{ key:"array2", title:"数组数字类型", type:"array<number>" }
```

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。


## 1.1.4（2021-06-10）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.5`
#### 2、【新增】`万能表格`新增属性`default-sort`，支持表格默认排序 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003876&doc_id=975983)
#### 如默认按时间降序
```html
<vk-data-table
  :default-sort="{ name:'_add_time', type:'desc' }"
></vk-data-table>
```
#### 3、【优化】`el-button` 组件支持 `vk-icon` 内置图标

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。


## 1.1.3（2021-05-31）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.2`
#### 2、【优化】`万能表格`中`tag`组件当没有匹配到值时进行忽略处理。
#### 3、【优化】`万能表格`中`time`组件正确识别10位数时间戳和13位时间戳，同时支持自定义时间g格式化
```js
{ key:"_add_time", title:"添加时间", type:"time", width:160, valueFormat:"yyyy-MM-dd hh:mm:ss" }
```

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论。
## 1.1.2（2021-05-31）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.1`
#### 2、【新增】补全内置组件文档 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050270&doc_id=975983)
#### 3、【修复】`上传组件` 上传视频时后缀名可能会错误的问题。
#### 4、【优化】`云函数URL化` 路由模式下，URL重写支持只允许部分云函数可被访问。（可以做到只暴露指定的API接口，增加URL化后的安全性）[点击URL重写规则](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=3916806&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.1.1（2021-05-29）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.1.0`
#### 2、【新增】用户管理新增强制重置其他账号登录密码。
#### 3、【新增】`table-select`、`address` 等组件文档 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050269&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.1.0（2021-05-29）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.19`
#### 2、【新增】用户管理新增强制重置其他账号登录密码。
#### 3、【新增】`table-select`、`address` 等组件文档 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050269&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.9（2021-05-28）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.19`
#### 2、【新增】强制重置admin账号密码教程 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4064984&doc_id=975983)
#### 3、【优化】`下拉选择`支持分组 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050278&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。
## 1.0.8（2021-05-27）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.18`
#### 2、【优化】`cascader` 组件的内部逻辑，支持异步加载。
#### 3、【修复】`上传组件` 上传视频时后缀名可能会错误的问题。
#### 4、【优化】将`系统设置`菜单变更为动态菜单（导入`database/动态菜单导入/系统设置.json`即可）
```js
动态菜单导入方式：
1、进入admin，点击菜单管理
2、点击通过JSON批量导入菜单
3、将`database/动态菜单导入/系统设置.json`内的全部内容复制到JSON内容中，点确定即可
4、可以删除`static_menu/menu.json`内的系统设置相关的菜单了。（由静态菜单变成了动态菜单）
```

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.7（2021-05-26）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
###  更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.18`
#### 2、【优化】`vk.baseDao.selects` 新增两个属性`getOne` 、 `getMain` [点击查看详情](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4054561&doc_id=975983)
#### 3、【优化】`万能表格`的搜索组件 新增`cascader`、`table-select`组件渲染。
#### 4、【优化】`万能表格`组件新增API `deleteRows`、`updateRows` （只更新表格内数据，不更新数据库）
```js
// 删除指定的行（不删数据库数据）
that.$refs.table1.deleteRows({
  ids:["60acf6248a69dc00018d8520"],
  success:function(){
    
  }
});
// 更新指定的行数据（不更新据库数据）
that.$refs.table1.updateRows({
  mode:"update", // update 局部字段更新 set 覆盖字段更新
  rows:[
    { _id:"60acf6248a69dc00018d8520", remark:"被修改了", money:10000 }
  ],
  success:function(){
    
  }
});
```

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.6（2021-05-24）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
###  更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.13`
#### 2、【优化】`万能表单`中单选和多选组的样式排版。增加属性`itemWidth` 所有选项的最小宽度。
#### 3、【优化】`remote-select`新增属性 `props` [点击查看组件文档](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050267&doc_id=975983)
#### 4、【优化】`radio` 和 `checkbox` 支持远程数据（通过云函数获取选项） [点击查看组件文档](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050276&doc_id=975983)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.5（2021-05-24）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
###  更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.11`
#### 2、【优化】`万能表单`中单选和多选组的样式排版。增加属性`itemWidth` 所有选项的最小宽度。
#### 3、【优化】`remote-select`新增属性 `props` [点击查看组件文档](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050267&doc_id=975983)
#### 4、【优化】`radio` 和 `checkbox` 支持远程数据（通过云函数获取选项） [点击查看组件文档](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4050276&doc_id=975983)
#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.4（2021-05-22）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
###  更新内容
#### 1、【优化】`vk.baseDao` API的查询性能。
#### 2、【调整】`vk.baseDao.getTableData` 默认排序规则调整为`_id`降序，之前是`_add_time`降序
#### 3、【优化】`vk.baseDao.getTableData` 和 `vk.baseDao.selects` 连表查询逻辑。

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.3（2021-05-20）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
###  更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.10`
#### 2、【修复】`pages_plugs/permission/list`页面`sort`的`type`为`number`(原本为`text`)

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.2（2021-05-18）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
###  更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.9`
#### 2、【新增】`JSON编辑器` `type: "json"` 可自由的编辑json对象 
![](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-cf0c5e69-620c-4f3c-84ab-f4619262939f/f3181c8a-efc7-4a73-8595-d7c029d0eac3.png)
#### 3、【修复】`vk-data-input-editor` 组件在其他组件中使用时功能异常的bug

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.1（2021-05-17）
### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
###  更新内容
#### 1、【升级】`vk-unicloud-admin-ui` 包升级至 `1.0.4`
#### 2、【优化】`opendb-admin-menus`(菜单表) 新增属性`hidden_menu` 若为true，则菜单存在，但在左侧菜单列表中隐藏。
#### 3、【修复】手机访问时，不显示用户角色权限菜单的bug。

#### 框架更新步骤指南 [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4023455&doc_id=975983)

##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 1.0.0（2021-05-15）

### 2021-05-15 `vk-unicloud-admin` 框架正式发布。

![](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-cf0c5e69-620c-4f3c-84ab-f4619262939f/6deebd32-8075-4bdb-8e04-5839516ef4f4.png)

### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 插件名称：`vk-unicloud-admin`
### 作者：VK

## 序
##### 如果你热爱编程，想快速入门云开发，欢迎使用`vk-unicloud`系列开发框架
##### 无需转变开发习惯，0成本上手云开发。
##### 框架内置了众多API、工具包，为你的业务扫平障碍。使你的项目刚起步进度就是50%（微信登录、短信、验证码、缓存、生成小程序码等等）
##### 从此你又get一个新技能，只需用js，轻松搞定前后台整体业务。
##### `client端`框架文档：`https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=2912167&doc_id=975983` [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=2912167&doc_id=975983)
##### `admin端`框架文档：`https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003875&doc_id=975983` [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003875&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

##### 框架体验地址

[点击进入admin框架体验地址](https://vkunicloud.fsq.pub/admin/)

#### 体验账号：
##### 高级管理员：test11（账号）123456（密码）可以执行绝大部分功能
##### 初级管理员：test12（账号）123456（密码）只能执行查询功能
##### 无权限用户：test13（账号）123456（密码）无admin登录权限

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 2021-05-15 `vk-unicloud-admin` 框架正式发布。

![](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-cf0c5e69-620c-4f3c-84ab-f4619262939f/6deebd32-8075-4bdb-8e04-5839516ef4f4.png)

### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 插件名称：`vk-unicloud-admin`
### 作者：VK

## 序
##### 如果你热爱编程，想快速入门云开发，欢迎使用`vk-unicloud`系列开发框架
##### 无需转变开发习惯，0成本上手云开发。
##### 框架内置了众多API、工具包，为你的业务扫平障碍。使你的项目刚起步进度就是50%（微信登录、短信、验证码、缓存、生成小程序码等等）
##### 从此你又get一个新技能，只需用js，轻松搞定前后台整体业务。
##### `client端`框架文档：`https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=2912167&doc_id=975983` [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=2912167&doc_id=975983)
##### `admin端`框架文档：`https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003875&doc_id=975983` [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003875&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

##### 框架体验地址

[点击进入admin框架体验地址](https://vkunicloud.fsq.pub/admin/)

#### 体验账号：
##### 高级管理员：test11（账号）123456（密码）可以执行绝大部分功能
##### 初级管理员：test12（账号）123456（密码）只能执行查询功能
##### 无权限用户：test13（账号）123456（密码）无admin登录权限

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

## 2021-05-15 `vk-unicloud-admin` 框架正式发布。

![](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-cf0c5e69-620c-4f3c-84ab-f4619262939f/6deebd32-8075-4bdb-8e04-5839516ef4f4.png)

### vk-unicloud-admin 框架研究Q群:`22466457` 如有问题或建议可以在群内讨论。
### 插件名称：`vk-unicloud-admin`
### 作者：VK

## 序
##### 如果你热爱编程，想快速入门云开发，欢迎使用`vk-unicloud`系列开发框架
##### 无需转变开发习惯，0成本上手云开发。
##### 框架内置了众多API、工具包，为你的业务扫平障碍。使你的项目刚起步进度就是50%（微信登录、短信、验证码、缓存、生成小程序码等等）
##### 从此你又get一个新技能，只需用js，轻松搞定前后台整体业务。
##### `client端`框架文档：`https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=2912167&doc_id=975983` [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=2912167&doc_id=975983)
##### `admin端`框架文档：`https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003875&doc_id=975983` [点击查看](https://gitee.com/vk-uni/vk-uni-cloud-router/wikis/pages?sort_id=4003875&doc_id=975983)
##### 框架学习Q群：`22466457` 欢迎萌新和大佬来使用和共同改进框架

##### 框架体验地址

[点击进入admin框架体验地址](https://vkunicloud.fsq.pub/admin/)

#### 体验账号：
##### 高级管理员：test11（账号）123456（密码）可以执行绝大部分功能
##### 初级管理员：test12（账号）123456（密码）只能执行查询功能
##### 无权限用户：test13（账号）123456（密码）无admin登录权限

### 如果你觉得框架对你有用，可以在下方进行评论，也可以进行赞赏。

